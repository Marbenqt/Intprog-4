<!DOCTYPE HTML>  
<html>
<body>

<h2>GET and POST Method</h2>


<h3>Submit using GET method:</h3>
<form method="GET">
  Name: <input type="text" name="name"><br><br>
  Address: <input type="text" name="address"><br><br>
  Age: <input type="text" name="age"><br><br>
  Group No: <input type="text" name="groupNo"><br><br>
  <input type="submit" value="Submit GET">
</form>


<h3>Submit using POST method:</h3>
<form method="POST">
  Name: <input type="text" name="name"><br><br>
  Address: <input type="text" name="address"><br><br>
  Age: <input type="text" name="age"><br><br>
  Group No: <input type="text" name="groupNo"><br><br>
  <input type="submit" value="Submit POST">
</form>


</body>
</html>
